#include <iostream>
#include <string> // For using std::string

int main() {
    // Integer variable
    int age = 25;
    std::cout << "Age: " << age << std::endl;

    // Floating-point variable
    double height = 5.9;
    std::cout << "Height: " << height << " feet" << std::endl;

    // Character variable
    char grade = 'A';
    std::cout << "Grade: " << grade << std::endl;

    // Boolean variable
    bool isStudent = true;
    std::cout << "Is Student: " << std::boolalpha << isStudent << std::endl;

    // String variable
    std::string name = "THEDEV3";
    std::cout << "Name: " << name << std::endl;

    // Constant variable
    const float pi = 3.14159f;
    std::cout << "Value of Pi: " << pi << std::endl;

    // Modifying variables
    age += 5; // Increase age by 5
    std::cout << "Updated Age: " << age << std::endl;

    height *= 2; // Double the height
    std::cout << "Updated Height: " << height << " feet" << std::endl;

    return 0; // Indicate successful program termination
}