#include <iostream>
using namespace std;

template <typename T>
T add(T m, T a) {
    return m + a;
}

int main() {
    cout << "Sum (int)" << add(13, 25) << endl;
    cout << "Sum (double)" << add(32.1, 62.2) << endl;
    
    return 0;
}