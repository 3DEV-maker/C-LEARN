#include <iostream>
using namespace std;

int main() {
    int birth, current;

    cout << "Enter Your Birth Year";
    cin ><
}