#include <iostream>
using namespace std;

int main() {
    int start, end;
    cout << "Input the starting number: ";
    cin >> start;
    cout << "Input the ending number: ";
    cin >> end;

    int evenSum = 0;
    int oddSum = 0;

    // Loop through the range from start to end
    for (int i = start; i <= end; i++) {
        if (i % 2 == 0) {
            evenSum += i; // Add to evenSum if the number is even
        } else {
            oddSum += i; // Add to oddSum if the number is odd
        }
    }

    cout << "Sum of even numbers: " << evenSum << endl;
    cout << "Sum of odd numbers: " << oddSum << endl;

    return 0;
}
