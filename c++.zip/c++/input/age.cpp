#include <iostream>
using namespace std;

int main() {
  int birthYear, currentYear;

  cout << "Enter Your BirthYear: ";
  cin >> birthYear;

  cout << "Enter currentYear: ";
  cin >> currentYear;

  int age = currentYear - birthYear;
  cout << "Your age is: " << age << " Years old" << endl;

  return 0;
}