#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

class Planet {
public:
    string name;
    double mass, radius;
    double x, y; // Position
    double vx, vy; // Velocity

    Planet(string n, double m, double r, double posX, double posY, double velX, double velY)
        : name(n), mass(m), radius(r), x(posX), y(posY), vx(velX), vy(velY) {}

    void updatePosition(double dt) {
        x += vx * dt;
        y += vy * dt;
    }

    void showInfo() {
        cout << name << " -> Position: (" << x << ", " << y << ")\n";
    }
};
