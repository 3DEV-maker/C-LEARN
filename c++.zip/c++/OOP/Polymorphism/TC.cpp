#include <iostream>
using namespace std;

template <typename T>
class Box {
public:
    T value;
    Box(T v) : value(v) {}
    void show() {cout << "Math School Points: " << value << endl; }
};

int main() {
  Box<int> intBox(19);
  Box<double> doubleBox(19.75);

  intBox.show();
  doubleBox.show();
  return 0;
}