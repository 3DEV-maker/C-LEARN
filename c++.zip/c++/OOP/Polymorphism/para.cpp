#include <iostream>
using namespace std;

template <typename T>
T add (T m, T a) {
  return m + a;
}

int main() {
  cout << "Sum (int)" << add(45, 30) << endl;
  cout << "Sum (double)" << add(23.1, 96.2) << endl;

  return 0;
}